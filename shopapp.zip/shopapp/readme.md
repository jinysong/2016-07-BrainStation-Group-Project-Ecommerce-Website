## HOW TO START

Install dependencies, from root run:
	npm install

Install Bower to add front end dependencies, from root run:
	sudo npm install bower -g

Install front end dependencies by navigating to app folder:
	cd app
Then running:
	bower install

To start server from root folder (go back a folder with cd ../) with : 
	node api/server.js


Initialize Admin Account:
	go to browser and type http://localhost:8080/api/init


#TODOs
NOTE THERE IS NO TODO #1's, only #2's and #3's. To Do ones are for the API and they are complete in this version of the app.

1. 	Complete Admin Panel in app/site/controllers/product.ctrl.js 
	resolve in app.js
	view app/partials/admin-edit-product.html


2. 	Complete Shop front page in app/site/controllers/shop.ctrl.js
	resolve in app.js 
	view app/partials/shop-main.html
